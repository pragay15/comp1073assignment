const nouns = ["dog", "cat", "bird", "tree", "mountain"];
const verbs = ["runs", "jumps", "flies", "sings", "grows"];
const adjectives = ["happy", "sad", "playful", "fast", "slow"];
const nouns2 = ["river", "cloud", "flower", "rock", "valley"];
const places = ["beach", "forest", "city", "cave", "desert"];

let textToSpeak = "";

function generateRandomPhrase(array) {
  const randomIndex = Math.floor(Math.random() * array.length);
  return array[randomIndex];
}

document.getElementById("nounBtn").addEventListener("click", function() {
  textToSpeak += generateRandomPhrase(nouns) + " ";
});

document.getElementById("verbBtn").addEventListener("click", function() {
  textToSpeak += generateRandomPhrase(verbs) + " ";
});

document.getElementById("adjBtn").addEventListener("click", function() {
  textToSpeak += generateRandomPhrase(adjectives) + " ";
});

document.getElementById("noun2Btn").addEventListener("click", function() {
  textToSpeak += generateRandomPhrase(nouns2) + " ";
});

document.getElementById("placeBtn").addEventListener("click", function() {
  textToSpeak += generateRandomPhrase(places) + " ";
});

document.getElementById("speakBtn").addEventListener("click", function() {
  speakNow();
});

function speakNow() {
  console.log("Speaking: " + textToSpeak);
  document.getElementById("output").textContent = textToSpeak; 
}